1. **Set Document Date on Invoice:**
   - Navigate to the invoice and set the document date. 
   - If the document date is not set, it will automatically be assigned the invoice date upon confirmation.

2. **Analytic Line Generation:**
   - If any line has analytic information, the generated analytic entry will inherit the document date.

3. **Setting Document Date in Reconcile View:**
   - You can also set the document date from the reconciliation view, but this option is available only during manual reconciliation.