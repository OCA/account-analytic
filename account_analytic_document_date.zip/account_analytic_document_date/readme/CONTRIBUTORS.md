- `APSL - Nagarro <https://apsl.tech>`__:

  - Miquel Pascual 
  - Bernat Obrador